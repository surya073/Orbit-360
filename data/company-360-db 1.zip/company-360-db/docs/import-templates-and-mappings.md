# Import Templates and Mappings

CSV templates: `templates/*.template.csv` (row 2 is an **EXAMPLE**, prefixed/fake; delete before use). Excel uses the same headers (first sheet unless the template sets a sheet). Source->target seeds: `db/seed/source_column_mappings.json`.

## Workflow & states
upload -> select module -> pick template / map columns -> preview -> validate -> resolve conflicts -> commit (batches) -> report.
`import_jobs.status`: uploaded, mapped, validating, validated, committing, completed, completed_with_errors, failed, cancelled, expired.
`import_rows.status`: valid, invalid, conflict, skipped, committed, failed.

## Mapping rules
- Mapping is by header text **and** `source_index` so duplicate headers work (projects has three Status-like columns).
- Unmapped source columns are kept in `more_details` (bounded JSON) - nothing is silently discarded.
- Transforms: `direct, date, number, boolean, split_yes_no_time, split_list, unpivot, lookup`.
- Project `Status` columns (CONFIRM with business before real import):
  - `Current Status` -> `current_status` (delivery status)
  - 1st `Status` (after `End Date`) -> `contract_status` (assumed contract/plan validity)
  - 2nd `Status` (after `Completed Date`) -> `completion_status` (assumed completion state)
- Attendance `Late Check-in (Yes/No) - Check-In Time` (`split_yes_no_time`): "Yes - 10:20" -> late_status=yes, time=10:20; "No" -> no, time empty; "10:05" alone -> time set, late_status=unknown unless cutoff setting is defined; unparseable -> row invalid. Verbatim kept in `late_checkin_raw`.
- Employee file: `AI` / `GIT HUB` unpivot into `ai_usage_records` (tool_category ai / github); `Number of Projects` is not stored; `Projects Allocated` / `Team Members` split into `project_assignments` after resolving each name/email to a project/employee (unresolved -> conflict row, not guessed).

## Matching strategy (priority order)
| Module | 1 | 2 | 3 (no blind name merge) |
|---|---|---|---|
| employees | source_system+source_record_id | email_normalized | employee_code; name-only => conflict for human review |
| projects | source_record_id | project_code | project_name + first_start_date + team (exact) => candidate conflict |
| project_assignments | project_id+employee_id (dedupe_key) | | |
| time_entries | source_record_id | employee+project+date+start+duration | duplicate candidate => conflict |
| attendance | employee+date | | |
| leave | employee+type+start+end | | |
| performance | employee+cycle+metric | | |
| ai_usage | employee+tool+project+period | | |
| product_items | source_system+source_record_id | | |

## Conflict handling
Conflict rows are held until a user picks **Update / Keep Existing / Skip** (per row or job default). Every resolution is written to `audit_logs` and `import_rows.resolution`. Commit only processes `valid` rows and resolved conflicts.

## Idempotency / retry
Commit in batches (`import_commit_batch_size`), recording `import_jobs.commit_cursor`. Upserts go through `dedupe_key`/source IDs, so a retried batch cannot duplicate rows. Re-upload of an identical file (same `file_sha256`+team+module) triggers a warning.

## Unmapped columns -> `more_details` (schema 1.1.0)
Every module has a fallback: any source column without a mapping is preserved in `more_details`.
1. Recognized columns go to standard fields. Those columns are **not** repeated in `more_details`.
2. Key = original header text. If a header needs normalizing, set `import_mappings.more_details_key`; the original header stays in the mapping row. Duplicate headers become `Header`, `Header#<index>`.
3. Types are kept (string stays string, number stays number, boolean stays boolean, dates -> ISO strings). Blank cells are omitted by default (absence = blank); templates can set `keepBlanks` to keep `""` vs `null` distinct.
4. A row with no extra values gets `more_details = NULL`, not `{}`. Keys are written sorted, so a retried import yields an identical value.
5. **Preview**: the mapping step lists every source column as *Mapped -> field*, *Unmapped -> more_details[key]*, or *Excluded*. `import_jobs.unmapped_column_count` and `mapping_snapshot` record it.
6. **Exclusion** is the only way to drop a column: mapping `transform=exclude` plus `exclude_ack_user_id` (user explicitly acknowledged). Templates with `unmapped_policy=require_ack` force this decision.
7. **Conflicts** (Update / Keep Existing / Skip): *Update* merges incoming keys over existing keys (other existing keys kept); *Keep Existing* and *Skip* leave `more_details` untouched. Choice recorded in `import_rows.resolution` and `audit_logs`.
8. **Errors**: `MORE_DETAILS_TOO_LARGE` (>limit) and `MORE_DETAILS_INVALID` (non-finite number, unsupported type, reserved key, corrupt existing JSON on merge) fail the row; the user can exclude/shorten and revalidate. Never truncated.
9. **Retries**: matching still uses source IDs / `dedupe_key`; deterministic serialization means a retry changes nothing.
10. Extra-column examples (skills, labels, external IDs...) are only possibilities; only columns actually present in the uploaded file are stored.
