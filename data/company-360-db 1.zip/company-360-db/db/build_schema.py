import json, os, csv
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
for d in ["db/schema","db/seed","docs","templates"]:
    os.makedirs(f"{OUT}/{d}", exist_ok=True)

def C(name, typ, req=False, uniq=False, note="", **kw):
    d = dict(name=name, type=typ, required=req, unique=uniq, note=note); d.update(kw); return d
def fk(name, parent, req=False, note="", on_delete="null"):
    return C(name, "foreignkey", req, False, note, parent=parent, on_delete=on_delete)
def V(name, n=255, req=False, uniq=False, note=""): return C(name, f"varchar({n})", req, uniq, note)
def T(name, req=False, note=""): return C(name, "text", req, False, note)
def src():
    return [V("source_system",60,note="e.g. company360_export, manual"),
            V("source_record_id",120,note="Stable ID from source file/app when present"),
            fk("import_job_id","import_jobs",note="Last import job that wrote this row")]
def soft():
    return [C("is_deleted","boolean",note="Soft delete; default false"),
            C("deleted_at","datetime"), fk("deleted_by_user_id","users")]
def dk(note): return V("dedupe_key",255,uniq=True,note=note)

MORE_MAX = 10000  # Catalyst Text hard limit (characters)
MORE = C("more_details","text",False,False,
  "Optional serialized JSON object (<=10,000 chars). Supplemental attributes with no standard column; never replaces standard fields. See docs.")
TABLES = []
def table(name, purpose, cols, indexes=(), kind="physical"):
    cols = [c for c in cols if c["name"] != "more_details"] + [dict(MORE)]
    TABLES.append(dict(name=name, purpose=purpose, kind=kind, columns=cols, indexes=list(indexes)))

table("teams","Team master. Scope boundary for manager access.",[
 V("team_code",60,True,True), V("name",150,True), T("description"), C("is_active","boolean")]+soft())

table("users","Application-user mapping (Catalyst auth user -> app role + team). users.team_id is single-valued, so a manager cannot belong to two teams.",[
 V("catalyst_user_id",40,True,True,"Catalyst Authentication user ID"),
 V("email",255,True,True,"Normalized lowercase"), V("display_name",150),
 V("app_role",20,True,note="admin | manager"),
 fk("team_id","teams",note="Required for manager (server-validated); NULL for admin"),
 fk("employee_id","employees",note="Optional link to employee master"),
 C("is_active","boolean")],
 [dict(cols=["app_role","team_id"],unique=False)])

table("employees","Employee identity and employment details. Project counts are derived from project_assignments.",[
 V("employee_code",60,uniq=True,note="Business code; source S.NO is NOT used as identity"),
 C("source_sno","int",note="Source `S.NO` (display order only)"),
 V("full_name",200,True), V("email_normalized",255,uniq=True,note="lower(trim(Email ID)); unique when present"),
 V("job_role",120,note="Source `Role`"), C("joining_date","date"),
 fk("reports_to_employee_id","employees",note="Resolved from `Reports To`"),
 V("reports_to_raw",200,note="Unresolved source text kept for review"),
 V("employment_status",30,note="Source `Status`: active|inactive|on_leave|unknown (validated against settings)"),
 fk("primary_team_id","teams",note="Denormalized current team for fast scoping; kept in sync with team_memberships"),]+src()+soft(),
 [dict(cols=["primary_team_id","employment_status"],unique=False),dict(cols=["source_system","source_record_id"],unique=False)])

table("team_memberships","Employee<->team history. One active row per employee/team enforced via dedupe_key.",[
 fk("team_id","teams",True,on_delete="cascade"), fk("employee_id","employees",True,on_delete="cascade"),
 V("membership_role",30,note="member|lead"), C("start_date","date"), C("end_date","date"),
 C("is_active","boolean"), dk("team_id|employee_id|start_date")]+src(),
 [dict(cols=["team_id","employee_id"],unique=False)])

table("projects","Project master. *_reported hour fields are source snapshots; authoritative actuals come from approved time_entries.",[
 V("project_code",60,uniq=True,note="Business code if exists"),
 C("source_sno","int",note="Source `S.NO`"),
 V("project_name",255,True), fk("team_id","teams",note="Owning team; drives manager scope"),
 V("project_type",80,note="`Type`"), V("plan_type",80,note="`Plan Type`"), V("region",80,note="`Region`"),
 V("current_status",60,note="Source `Current Status` (col 6): delivery/lifecycle status"),
 V("contract_status",60,note="Source 1st `Status` (after `End Date`): ASSUMED contract/plan validity - CONFIRM"),
 V("completion_status",60,note="Source 2nd `Status` (after `Completed Date`): ASSUMED delivery completion - CONFIRM"),
 V("meeting_schedule",150,note="`Internal Meeting Day and Timing`"),
 V("second_host_raw",200,note="`2nd Host` raw"), fk("second_host_employee_id","employees"),
 C("first_start_date","date"), C("current_start_date","date"), C("end_date","date"),
 C("internal_due_date","date"), C("client_due_date","date"), C("completed_date","date"),
 C("total_renewals","int"), C("hours_purchased_past","double",note="`Total Hrs Purchased(Past)`"),
 C("hours_purchased_current","double",note="`Current Hrs Purchased`"),
 C("hours_used_reported","double",note="`Total Hrs used till now` (snapshot)"),
 C("estimated_hours","double"), C("actual_hours_reported","double",note="`Actual Hours` (snapshot)"),
 C("hours_reconciled","double",note="Cached SUM(approved time_entries)/60; refreshed server-side"),
 C("hours_reconciled_at","datetime"),
 T("comments"), T("delay_reason",note="`Client Side /Zoho Side delay reason`"),
 T("consumption_report_url",note="URL; may exceed 255 chars"), V("bandwidth",60),]+src()+soft(),
 [dict(cols=["team_id","current_status"],unique=False),dict(cols=["source_system","source_record_id"],unique=False)])

table("project_assignments","Employee<->project. N employees on a project = N rows; hours live in time_entries.",[
 fk("project_id","projects",True,on_delete="cascade"), fk("employee_id","employees",True,on_delete="cascade"),
 V("role_in_project",120,note="`Role in Project`"), C("is_second_host","boolean"),
 C("allocation_percent","double",note="`Bandwidth`/allocation if per-person"),
 C("contribution_percent_reported","double",note="`% Contribution Towards the Project` (reported, not verified)"),
 C("is_working","boolean",note="From `Team Members Working`"),
 C("start_date","date"), C("end_date","date"), C("is_active","boolean"),
 dk("project_id|employee_id")]+src()+soft(),
 [dict(cols=["employee_id"],unique=False),dict(cols=["project_id"],unique=False)])

table("time_entries","One row per employee per project per work block. Durations in minutes.",[
 fk("employee_id","employees",True), fk("project_id","projects",True),
 fk("team_id","teams",note="Snapshot of project team at entry time; set server-side"),
 C("work_date","date",True), C("start_at","datetime"), C("end_at","datetime"),
 C("duration_minutes","int",True,note=">=0; zero is a valid value, missing is not stored as 0"),
 C("is_billable","boolean",True), V("work_category",60,note="billable|non_billable|internal|support|..."),
 T("work_description"),
 V("approval_status",20,True,note="pending|approved|rejected"),
 fk("approved_by_user_id","users"), C("approved_at","datetime"),
 V("dedupe_key",255,uniq=True,note="source_record_id, else employee|project|work_date|start|duration|hash")]+src()+soft(),
 [dict(cols=["project_id","work_date"],unique=False),dict(cols=["employee_id","work_date"],unique=False),
  dict(cols=["team_id","work_date","approval_status"],unique=False)])

table("attendance_records","Daily check-in. Source combined column is split into late_status + check_in_time_local.",[
 fk("employee_id","employees",True), fk("team_id","teams"),
 C("attendance_date","date",True), V("reporting_month",7,note="YYYY-MM"),
 V("check_in_time_local",8,note="HH:mm[:ss] in Asia/Kolkata; empty = not recorded"),
 V("late_status",10,True,note="yes|no|unknown (unknown != no)"),
 T("late_reason"),
 V("late_checkin_raw",120,note="Verbatim `Late Check-in (Yes/No) - Check-In Time`"),
 dk("employee_id|attendance_date")]+src()+soft(),
 [dict(cols=["team_id","attendance_date"],unique=False),dict(cols=["employee_id","attendance_date"],unique=False)])

table("leave_records","Leave with distinguishable lifecycle status.",[
 fk("employee_id","employees",True), fk("team_id","teams"), V("leave_type",60,True),
 C("start_date","date",True), C("end_date","date",True),
 C("units","double"), V("unit_type",10,note="days|hours"),
 V("status",20,True,note="requested|approved|rejected|cancelled"),
 T("reason",note="Privacy-restricted: admin + owning manager only"),
 fk("approver_user_id","users"), C("decided_at","datetime"),
 dk("employee_id|leave_type|start_date|end_date")]+src()+soft(),
 [dict(cols=["employee_id","start_date"],unique=False),dict(cols=["team_id","status"],unique=False)])

table("metric_definitions","Configured metrics/weights. Aggregate scores may only use rows here.",[
 V("metric_code",80,True,True), V("name",150,True), V("module",40,True,note="performance|product|usage|..."),
 V("value_type",20,note="numeric|rating|text|boolean"), C("scale_min","double"), C("scale_max","double"),
 C("weight","double",note="NULL = excluded from aggregates"), V("aggregation",20,note="avg|sum|latest"),
 T("description"), C("is_active","boolean")])

table("performance_records","Metric-level performance; no built-in score.",[
 fk("employee_id","employees",True), fk("team_id","teams"),
 V("review_cycle",60,True), C("period_start","date",True), C("period_end","date",True),
 fk("metric_definition_id","metric_definitions",True),
 C("metric_value","double"), V("metric_text",255), V("metric_scale",40),
 fk("reviewer_user_id","users"), fk("reviewer_employee_id","employees"),
 V("review_status",20,True,note="draft|submitted|finalized"),
 T("comments"), T("evidence_ref",note="Reference to evidence"),
 dk("employee_id|review_cycle|metric_definition_id")]+src()+soft(),
 [dict(cols=["employee_id","review_cycle"],unique=False),dict(cols=["team_id","period_start"],unique=False)])

table("ai_usage_records","Tool usage as reported. One row per employee x tool (x project) x period.",[
 fk("employee_id","employees",True), fk("project_id","projects"), fk("team_id","teams"),
 V("tool_name",100,True,note="Free text/provider; new tools need no schema change"),
 V("tool_category",30,True,note="ai|github|other"), V("access_type",60),
 V("is_shared_access",10,note="yes|no|unknown"),
 T("shared_access_raw",note="`Users who using other's Access`"),
 C("usage_percent_reported","double",note="`Percentage % Using` as REPORTED; not billable/productivity"),
 T("usage_purpose",note="`Using for`"), T("projects_raw",note="`Used for which Projects` raw"),
 V("reporting_period",20,note="e.g. 2026-10; required when known"),
 dk("employee_id|tool_name|project_id|reporting_period")]+src()+soft(),
 [dict(cols=["employee_id","tool_category"],unique=False),dict(cols=["team_id","reporting_period"],unique=False)])

table("product_items","Tasks/features/bugs/releases/milestones. Type-specific fields nullable.",[
 V("item_type",20,True,note="task|feature|bug|release|milestone"),
 V("title",255,True), T("description"), fk("project_id","projects"), fk("team_id","teams"),
 V("status",40), V("priority",20),
 fk("assignee_employee_id","employees"), fk("reporter_employee_id","employees"),
 fk("parent_item_id","product_items"), fk("release_item_id","product_items",note="Release/milestone this item targets"),
 C("created_on","date",note="Source created date (system CREATEDTIME is import time)"),
 C("start_date","date"), C("due_date","date"), C("completed_date","date"),
 C("estimated_hours","double"), C("actual_hours","double"),
 dk("source_system|source_record_id")]+src()+soft(),
 [dict(cols=["project_id","item_type","status"],unique=False),dict(cols=["assignee_employee_id"],unique=False)])

table("product_item_links","Many-to-many item relations (blocks, relates_to, fixed_in).",[
 fk("item_id","product_items",True,on_delete="cascade"), fk("linked_item_id","product_items",True,on_delete="cascade"),
 V("link_type",30,True), dk("item_id|linked_item_id|link_type")])

table("import_templates","Per-module reusable templates (system or team-owned).",[
 V("module",40,True), V("name",150,True), V("version",20), V("file_type",10,note="csv|xlsx|both"),
 C("header_row","int",note="1-based"), fk("team_id","teams",note="NULL = global"),
 C("is_system","boolean"), C("is_active","boolean"),
 V("unmapped_policy",20,note="more_details (default) | require_ack"),
 V("dedupe_key",255,uniq=True,note="module|name|version|team_id")])

table("import_mappings","Source column -> target field with transforms.",[
 fk("template_id","import_templates",True,on_delete="cascade"),
 V("source_column",200,True,note="Header text"), C("source_index","int",note="0-based; disambiguates duplicate headers"),
 V("target_field",100,note="NULL = unmapped: preserved into more_details"),
 V("more_details_key",200,note="JSON property name when normalization of the header is needed; default = original header"),
 fk("exclude_ack_user_id","users",note="Required when transform=exclude: user who explicitly chose NOT to import this column"),
 V("transform",40,note="direct|date|number|boolean|split_yes_no_time|split_list|unpivot|lookup|exclude"),
 T("transform_options",note="JSON"), C("is_required","boolean"), C("sort_order","int")],
 [dict(cols=["template_id","sort_order"],unique=False)])

table("import_jobs","One row per upload/commit run.",[
 V("module",40,True), fk("template_id","import_templates"), fk("team_id","teams"),
 V("file_name",255,True), V("file_type",10), C("file_store_file_id","bigint",note="Catalyst File Store ID of source file"),
 V("file_sha256",64), fk("uploaded_by_user_id","users",True),
 V("status",30,True,note="uploaded|mapped|validating|validated|committing|completed|completed_with_errors|failed|cancelled|expired"),
 V("default_conflict_policy",20,note="update|keep_existing|skip|ask"),
 C("total_rows","int"), C("valid_rows","int"), C("invalid_rows","int"), C("conflict_rows","int"),
 C("unmapped_column_count","int"), C("more_details_error_rows","int"),
 C("created_rows","int"), C("updated_rows","int"), C("skipped_rows","int"), C("failed_rows","int"),
 C("started_at","datetime"), C("finished_at","datetime"), T("error_summary"),
 T("mapping_snapshot",note="JSON of mappings used (bounded)"),
 C("file_expires_at","datetime"), C("commit_cursor","int",note="Last committed row_number for safe resume"),
 V("dedupe_key",255,note="team|module|file_sha256 - warns on re-upload")],
 [dict(cols=["team_id","module","status"],unique=False),dict(cols=["file_sha256"],unique=False)])

table("import_rows","Per-row validation/commit result. NO raw payload; payload lives in File Store (ndjson).",[
 fk("import_job_id","import_jobs",True,on_delete="cascade"), C("row_number","int",True),
 V("status",20,True,note="valid|invalid|conflict|skipped|committed|failed"),
 V("business_key",255,note="Matching key used (not raw PII where avoidable)"),
 C("conflict_target_row_id","bigint"), V("resolution",20,note="update|keep_existing|skip"),
 fk("resolved_by_user_id","users"), C("resolved_at","datetime"),
 V("error_codes",255,note="Comma list e.g. MISSING_REQUIRED,INVALID_DATE"),
 T("error_detail",note="Field names + reason only, no sensitive values"),
 V("row_hash",64), V("dedupe_key",255,uniq=True,note="import_job_id|row_number")],
 [dict(cols=["import_job_id","status"],unique=False)])

table("report_snapshots","Frozen dashboard/report outputs. Retention default 365 days; source records are never deleted by expiry.",[
 V("report_type",60,True), fk("team_id","teams"), C("period_start","date"), C("period_end","date"),
 V("reporting_period",20), T("parameters",note="JSON filters"),
 T("summary_json",note="Small summaries only"), C("data_file_id","bigint",note="File Store ID for large payloads"),
 V("data_version",20), V("status",20), fk("generated_by_user_id","users"),
 C("generated_at","datetime"), C("expires_at","datetime",note="generated_at + retention setting")],
 [dict(cols=["report_type","reporting_period","team_id"],unique=False),dict(cols=["expires_at"],unique=False)])

table("saved_presentations","Full-screen presentation definitions. Visible to all managers of team_id; admins see all.",[
 V("title",200,True), fk("team_id","teams",note="NULL only for admin-created cross-team decks"),
 fk("created_by_user_id","users",True), T("slides_config",note="JSON; references snapshot IDs"),
 V("status",20), C("last_presented_at","datetime")]+soft(),
 [dict(cols=["team_id"],unique=False)])

table("audit_logs","Append-only. Written server-side only.",[
 fk("actor_user_id","users"), V("action",40,True,note="create|update|delete|import_commit|conflict_resolve|login|..."),
 V("entity_table",60,True), C("entity_row_id","bigint"), fk("team_id","teams"), fk("import_job_id","import_jobs"),
 T("before_json",note="Redacted"), T("after_json",note="Redacted"), T("reason"), V("request_id",60)],
 [dict(cols=["entity_table","entity_row_id"],unique=False),dict(cols=["actor_user_id"],unique=False)])

table("application_settings","Configuration key/values.",[
 V("setting_key",100,True), V("scope",10,note="global|team"), fk("team_id","teams"),
 T("setting_value"), V("value_type",20), T("description"),
 V("dedupe_key",255,uniq=True,note="scope|team_id|setting_key")])

schema = dict(project_id="46135000000311001", timezone="Asia/Kolkata", schema_version="1.1.0",
  generated_by="build.py",
  catalyst_notes=["Every table has system columns ROWID (PK), CREATORID, CREATEDTIME, MODIFIEDTIME - do not recreate; use as created_at/updated_at.",
   "Tables/columns must be created in the Catalyst Console (no DDL in ZCQL; verify CLI before assuming).",
   "Uniqueness is per single column; composite uniqueness uses the dedupe_key column.",
   "Max 100 columns per table (dev). Varchar max 255.","Foreign key stores parent ROWID; on-delete null|cascade."],
  more_details_spec=dict(type="text",max_chars=MORE_MAX,format="JSON object (serialized)",nullable=True,tables="all"),
  derived_not_tables=["employee project count","project billable/non-billable totals","dashboard KPIs","late-check-in rate"],
  tables=TABLES)
json.dump(schema, open(f"{OUT}/db/schema/company360.schema.json","w"), indent=2)

# data dictionary
md = ["# Database Schema & Data Dictionary","",
 "Generated from `db/schema/company360.schema.json` (do not hand-edit; edit `build.py`/schema JSON).","",
 "Every table also has Catalyst system columns `ROWID` (PK), `CREATORID`, `CREATEDTIME` (= created_at), `MODIFIEDTIME` (= updated_at).",
 "`fk` = Foreign Key to parent `ROWID`. Required = Mandatory in Console. Timestamps are not duplicated.",""]
md += ["## `more_details` (every table)","",
 "Optional Text column holding one serialized JSON **object** (max 10,000 characters; Catalyst has no JSON type). NULL means no extra data. Holds supplemental attributes that have no standard column (e.g. unmapped source-sheet columns). It never replaces standard, queryable fields, and it is not used for permissions, scoping, or validation decisions. See `import-templates-and-mappings.md` and `data-validation-rules.md`.",""]
for t in TABLES:
    md += [f"## `{t['name']}`","",t["purpose"],"","| Column | Type | Req | Unique | Notes |","|---|---|---|---|---|"]
    for c in t["columns"]:
        ty = c["type"] if c["type"]!="foreignkey" else f"fk → {c['parent']} (on delete {c['on_delete']})"
        md.append(f"| `{c['name']}` | {ty} | {'Y' if c['required'] else ''} | {'Y' if c['unique'] else ''} | {c['note']} |")
    if t["indexes"]:
        md += ["","Recommended compound/extra indexes (verify Console support): "+"; ".join("`"+", ".join(i['cols'])+"`" for i in t["indexes"])]
    md.append("")
open(f"{OUT}/docs/database-schema.md","w").write("\n".join(md))

# CSV templates (example rows marked EXAMPLE)
TPL = {
 "employees": (["Full Name","S.NO","Email ID","Role","Joining Date","Reports To","Status","Team Code"],
               ["EXAMPLE Jane Doe","1","example.jane@example.com","Developer","2024-01-15","EXAMPLE John Roe","active","TEAM-EXAMPLE"]),
 "projects": (["S.NO","Project Name","Internal Meeting Day and Timing","Type","Plan Type","Current Status","Region","2nd Host","First Start Date","Total Renewals","Total Hrs Purchased(Past)","Current Hrs Purchased","Total Hrs used till now","Current Start Date","End Date","Status","Comments","Internal Due Date","Client Due Date","Client Side /Zoho Side delay reason","Completed Date","Status","Consumption Report Link","Bandwidth","Estimated Hours","Actual Hours","Team Code"],
              ["1","EXAMPLE Project","Mon 10:00","Implementation","Retainer","In Progress","APAC","","2025-01-01","0","0","100","40","2025-01-01","2025-12-31","Active","","2025-11-30","2025-12-15","","","In Progress","https://example.com/report","","100","40","TEAM-EXAMPLE"]),
 "project_assignments": (["Project Name","Project Code","Employee Email","Role in Project","Is 2nd Host (Yes/No)","Working (Yes/No)","% Contribution Towards the Project","Start Date","End Date"],
              ["EXAMPLE Project","","example.jane@example.com","Developer","No","Yes","50","2025-01-01",""]),
 "time_entries": (["Employee Email","Project Name","Project Code","Work Date","Start Time","End Time","Duration (hours)","Billable (Yes/No)","Category","Description","Approval Status","Approved By Email","Approved At","Entry ID"],
              ["example.jane@example.com","EXAMPLE Project","","2025-02-03","09:30","13:30","4","Yes","billable","EXAMPLE work","approved","example.admin@example.com","2025-02-04 10:00","EXAMPLE-1"]),
 "attendance": (["IT Team Member","Month","Date","Late Check-in (Yes/No) - Check-In Time","Reason"],
              ["EXAMPLE Jane Doe","February","2025-02-03","Yes - 10:20","EXAMPLE traffic"]),
 "leave_records": (["Employee Email","Leave Type","Start Date","End Date","Units","Unit Type","Status","Reason","Approver Email","Decided At","Leave ID"],
              ["example.jane@example.com","EXAMPLE casual","2025-03-10","2025-03-11","2","days","approved","","example.admin@example.com","2025-03-01","EXAMPLE-1"]),
 "performance_records": (["Employee Email","Review Cycle","Period Start","Period End","Metric Code","Metric Value","Metric Scale","Reviewer Email","Review Status","Comments","Evidence Ref","Record ID"],
              ["example.jane@example.com","EXAMPLE-2025-H1","2025-01-01","2025-06-30","EXAMPLE_METRIC","4","1-5","example.admin@example.com","draft","","","EXAMPLE-1"]),
 "ai_usage": (["Full Name","S.NO","Email ID","Role","AI","GIT HUB","Users who using other's Access","Used for which Projects","Percentage % Using","Using for","Reporting Period"],
              ["EXAMPLE Jane Doe","1","example.jane@example.com","Developer","EXAMPLE Tool A","EXAMPLE Tool B","No","EXAMPLE Project","30","EXAMPLE drafting","2025-02"]),
 "product_items": (["Item ID","Item Type","Title","Description","Project Name","Status","Priority","Assignee Email","Reporter Email","Created Date","Start Date","Due Date","Completed Date","Parent Item ID","Release Item ID","Estimated Hours","Actual Hours"],
              ["EXAMPLE-1","task","EXAMPLE task","","EXAMPLE Project","open","medium","example.jane@example.com","example.admin@example.com","2025-02-01","","2025-02-15","","","","8",""]),
}
for k,(h,ex) in TPL.items():
    with open(f"{OUT}/templates/{k}.template.csv","w",newline="") as f:
        w=csv.writer(f); w.writerow(h); w.writerow(ex)

MAP = {  # source header -> target (module-level mapping seeds)
 "employees": {"Full Name":"employees.full_name","S.NO":"employees.source_sno","Email ID":"employees.email_normalized[lower,trim]","Role":"employees.job_role","Joining Date":"employees.joining_date[date]","Reports To":"employees.reports_to_employee_id[lookup email|name; else reports_to_raw]","Status":"employees.employment_status","Number of Projects":"IGNORED->derived (kept in more_details if present)","AI":"-> ai_usage_records (tool_category=ai) [unpivot]","GIT HUB":"-> ai_usage_records (tool_category=github) [unpivot]","Users who using other's Access":"-> ai_usage_records.shared_access_raw","Used for which Projects":"-> ai_usage_records.projects_raw","Percentage % Using":"-> ai_usage_records.usage_percent_reported","Using for":"-> ai_usage_records.usage_purpose","Projects Allocated":"-> project_assignments (split_list) ; raw kept in more_details"},
 "projects": {"S.NO":"source_sno","Project Name":"project_name","Internal Meeting Day and Timing":"meeting_schedule","Type":"project_type","Plan Type":"plan_type","Current Status":"current_status","Region":"region","Team Members":"-> project_assignments (split_list)","2nd Host":"second_host_raw / second_host_employee_id","Role in Project":"-> project_assignments.role_in_project","First Start Date":"first_start_date","Total Renewals":"total_renewals","Total Hrs Purchased(Past)":"hours_purchased_past","Current Hrs Purchased":"hours_purchased_current","Total Hrs used till now":"hours_used_reported","Current Start Date":"current_start_date","End Date":"end_date","Status (index 17, after End Date)":"contract_status [CONFIRM]","Comments":"comments","Internal Due Date":"internal_due_date","Client Due Date":"client_due_date","Client Side /Zoho Side delay reason":"delay_reason","Completed Date":"completed_date","Status (index 23, after Completed Date)":"completion_status [CONFIRM]","Consumption Report Link":"consumption_report_url","Bandwidth":"bandwidth","Estimated Hours":"estimated_hours","Actual Hours":"actual_hours_reported","Team Members Working":"-> project_assignments.is_working","% Contribution Towards the Project":"-> project_assignments.contribution_percent_reported"},
 "attendance": {"IT Team Member":"employee_id [lookup email/code/name; ambiguous names -> conflict]","Month":"reporting_month","Date":"attendance_date","Late Check-in (Yes/No) - Check-In Time":"split_yes_no_time -> late_status + check_in_time_local; verbatim -> late_checkin_raw","Reason":"late_reason"},
}
for _m in TPL:
    MAP.setdefault(_m, {})
    MAP[_m]["__unmapped__"] = "any source column without a mapping -> more_details[<original header>] (or more_details_key); never discarded unless a user explicitly excludes it (transform=exclude + exclude_ack_user_id)"
json.dump(MAP, open(f"{OUT}/db/seed/source_column_mappings.json","w"), indent=2)
json.dump([
 {"setting_key":"more_details_max_chars","scope":"global","setting_value":"10000","value_type":"int","description":"Catalyst Text hard limit; may be lowered, never raised"},
 {"setting_key":"business_timezone","scope":"global","setting_value":"Asia/Kolkata","value_type":"string"},
 {"setting_key":"report_snapshot_retention_days","scope":"global","setting_value":"365","value_type":"int"},
 {"setting_key":"import_file_retention_days","scope":"global","setting_value":"30","value_type":"int","description":"PROPOSED - confirm"},
 {"setting_key":"import_row_retention_days","scope":"global","setting_value":"90","value_type":"int","description":"PROPOSED - confirm"},
 {"setting_key":"import_commit_batch_size","scope":"global","setting_value":"100","value_type":"int","description":"PROPOSED - tune against Catalyst function timeout"},
 {"setting_key":"late_checkin_cutoff_time","scope":"global","setting_value":"","value_type":"string","description":"UNSET - business must define; not inferred"}
], open(f"{OUT}/db/seed/application_settings.json","w"), indent=2)
print(len(TABLES),"tables;", sum(len(t["columns"]) for t in TABLES),"cols")
print({t["name"]:len(t["columns"])+4 for t in TABLES})


# ---------- validation ----------
EXPECTED = ["teams","users","employees","team_memberships","projects","project_assignments","time_entries","attendance_records","leave_records","performance_records","ai_usage_records","product_items","product_item_links","metric_definitions","application_settings","import_templates","import_mappings","import_jobs","import_rows","report_snapshots","saved_presentations","audit_logs"]
names=[t["name"] for t in TABLES]
assert sorted(names)==sorted(EXPECTED) and len(names)==len(set(names))==22, "table set mismatch"
SYSTEM_COLS={"rowid","creatorid","createdtime","modifiedtime"}
for t in TABLES:
    cn=[c["name"] for c in t["columns"]]
    assert len(cn)==len(set(cn)), f"duplicate column in {t['name']}"
    assert cn.count("more_details")==1 and cn[-1]=="more_details", f"more_details missing in {t['name']}"
    assert not (SYSTEM_COLS & {c.lower() for c in cn}), f"system column redefined in {t['name']}"
    assert len(cn)+4<=100, f"{t['name']} exceeds 100 columns"
    for c in t["columns"]:
        if c["type"]=="foreignkey": assert c["parent"] in names, f"bad FK parent {t['name']}.{c['name']}"
        if c["type"].startswith("varchar"): assert int(c["type"][8:-1])<=255
    for i in t["indexes"]:
        assert all(x in cn for x in i["cols"]), f"bad index cols {t['name']}"
chk=json.load(open(f"{OUT}/db/schema/company360.schema.json"))
assert len(chk["tables"])==22 and all(t["columns"][-1]["name"]=="more_details" for t in chk["tables"])

# ---------- Console checklist ----------
deps={t["name"]:{c["parent"] for c in t["columns"] if c["type"]=="foreignkey" and c["parent"]!=t["name"]} for t in TABLES}
order=[]; left=set(names)
while left:
    ready=sorted(n for n in left if deps[n]<=set(order))
    pick=ready[0] if ready else sorted(left,key=lambda n:(len(deps[n]-set(order)),n))[0]
    order.append(pick); left.discard(pick)
def ctype(c):
    ty=c["type"]
    if ty.startswith("varchar"): return f"Var Char (max {ty[8:-1]})"
    return {"text":"Text (max 10,000)","int":"Int","bigint":"Big Int","double":"Double","boolean":"Boolean","date":"Date","datetime":"DateTime","foreignkey":"Foreign Key"}[ty]
L=["# Catalyst Console Checklist (generated - do not hand-edit)","",
 "Project `46135000000311001` (Development). **Status: NOT created remotely.** Tick items only after verifying in the Console.","",
 "Console type names: confirm the exact dropdown labels (Int / Big Int / Double / Boolean / Date / DateTime) when creating the first column of each type.","",
 "Do NOT add ROWID, CREATORID, CREATEDTIME, MODIFIEDTIME - Catalyst creates them.","",
 "## Phase 1 - create all 22 tables and their non-FK columns","",
 "Create tables in this order (phase 1 has no FK columns, so any order works; after phase 1 every FK parent exists, so phase 2 order is free):","", ", ".join(f"`{n}`" for n in order),""]
tmap={t["name"]:t for t in TABLES}
for n in order:
    t=tmap[n]; L+=[f"### [ ] `{n}`","","| ok | Column | Type | Mandatory | Unique | Phase |","|---|---|---|---|---|---|"]
    for c in t["columns"]:
        ph="2 (after parent exists)" if c["type"]=="foreignkey" else "1"
        ty=ctype(c)+(f" -> `{c['parent']}`, on delete {c['on_delete']}" if c["type"]=="foreignkey" else "")
        L.append(f"| [ ] | `{c['name']}` | {ty} | {'Yes' if c['required'] else ''} | {'Yes' if c['unique'] else ''} | {ph} |")
    if t["indexes"]: L+=["","Indexes (only if Console supports): "+"; ".join("`"+", ".join(i["cols"])+"`" for i in t["indexes"])]
    L.append("")
L+=["## Phase 2 - Foreign Key columns","Add every row marked phase 2 above, in any order. Self-references (`employees.reports_to_employee_id`, `product_items.parent_item_id/release_item_id`) are added after their own table exists.","",
    "## Phase 3 - seed","Load `db/seed/application_settings.json` (config only, no company data).","",
    "## Phase 4 - verify","Compare the Console Schema View of each table with this list; record column count (expected = columns listed + 4 system)."]
open(f"{OUT}/docs/catalyst-console-checklist.md","w").write("\n".join(L))
print("VALIDATION OK:",len(names),"tables; more_details in all; max cols",max(len(t["columns"])+4 for t in TABLES))
