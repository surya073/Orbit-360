import json, os, unittest
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
S = json.load(open(os.path.join(ROOT, "db/schema/company360.schema.json")))
class T(unittest.TestCase):
    def test_22_tables(self): self.assertEqual(len(S["tables"]), 22)
    def test_more_details_everywhere(self):
        for t in S["tables"]:
            c = [x for x in t["columns"] if x["name"] == "more_details"]
            self.assertEqual(len(c), 1, t["name"]); self.assertEqual(c[0]["type"], "text"); self.assertFalse(c[0]["required"]); self.assertFalse(c[0]["unique"])
    def test_limits(self):
        for t in S["tables"]:
            self.assertLessEqual(len(t["columns"]) + 4, 100)
            for c in t["columns"]:
                if c["type"].startswith("varchar"): self.assertLessEqual(int(c["type"][8:-1]), 255, (t["name"], c["name"]))
    def test_no_legacy_source_extra(self):
        self.assertNotIn("source_extra", json.dumps(S))
    def test_core_fields_intact(self):
        cols = lambda n: {c["name"] for t in S["tables"] if t["name"] == n for c in t["columns"]}
        self.assertLessEqual({"employee_id", "project_id", "work_date", "duration_minutes", "is_billable", "approval_status"}, cols("time_entries"))
        self.assertLessEqual({"late_status", "check_in_time_local", "attendance_date"}, cols("attendance_records"))
        self.assertIn("team_id", cols("users")); self.assertLessEqual({"project_id", "employee_id"}, cols("project_assignments"))
        self.assertLessEqual({"status", "import_job_id", "resolution"}, cols("import_rows"))
if __name__ == "__main__": unittest.main()
