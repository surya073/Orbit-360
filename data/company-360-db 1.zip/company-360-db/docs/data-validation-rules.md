# Data Validation Rules

Enforced server-side in Catalyst Functions (Data Store checks only mandatory/unique/FK).

| Type | Rule |
|---|---|
| Email | trim, lowercase, RFC-style regex; invalid => row error `INVALID_EMAIL` |
| Dates | ISO `YYYY-MM-DD` preferred; also accept `DD-MM-YYYY`, `DD/MM/YYYY`, Excel serials per template `transform_options`. Ambiguous `01/02/2025` requires template-declared format. Invalid => `INVALID_DATE`. Date ranges: end >= start |
| Times | `HH:mm[:ss]` 24h or `h:mm AM/PM`, interpreted in Asia/Kolkata |
| Numbers | locale-safe parse; hours >= 0; percent 0-100 unless metric scale says otherwise; non-numeric => `INVALID_NUMBER` |
| Durations | stored in minutes (hours x 60, rounded to int; reject fractions of a minute > tolerance) |
| Booleans | yes/no/true/false/1/0 (case-insens.); other => `INVALID_BOOLEAN` |
| Status values | validated against allowed lists (settings/metric config); unknown => warning or error per template, never auto-mapped |
| References | employee/project/team must resolve uniquely; zero => `UNRESOLVED_REF`, many => `AMBIGUOUS_REF` (conflict) |
| Required | per template `is_required` + schema Mandatory; => `MISSING_REQUIRED` |
| Missing values | empty/`N/A`/`-` => NULL (never 0, never a default). `0` stays 0 |
| Time entries | must have employee + project + work_date + duration; approval_status in pending/approved/rejected; assignment should exist (warn if not) |
| Leave | status in requested/approved/rejected/cancelled |
| Hierarchy | product_items parent cannot be self/cycle; release_item_id must be item_type release/milestone |
| Duplicates in file | same business key twice in one file => both flagged `DUPLICATE_IN_FILE` |

Error output stores field name + code only (no raw cell values) in `import_rows`.

## `more_details`
| Rule | Detail |
|---|---|
| Format | NULL, or a JSON **object** (not array/string/number) serialized as text |
| Size | <= 10,000 characters (Catalyst Text limit); `more_details_max_chars` setting may lower, never raise. Counted on the serialized string. Over limit => `MORE_DETAILS_TOO_LARGE`, no truncation |
| Values | string, finite number, boolean, ISO date string, null. Nested objects/arrays/functions/NaN/Infinity => `MORE_DETAILS_INVALID` |
| Keys | non-empty, not `__proto__`/`constructor`/`prototype`; duplicates get `#<index>` |
| Precedence | If a column maps to a standard field, its value is stored there only. API writes that put a standard field name inside `more_details` are rejected |
| Merge (Update) | incoming keys overwrite, others kept; result re-validated for size/format; corrupt existing value => `MORE_DETAILS_INVALID` |
| PII | Not a hiding place: values are subject to the same read permissions and audit as the row |
