# Database Architecture

Project: Company 360 (Catalyst ID `46135000000311001`). Timezone: `Asia/Kolkata`.

## Platform constraints (from Catalyst docs)
- Tables/columns are created in the Console; ZCQL has no DDL. Verify any CLI/API option before relying on it.
- Every table has `ROWID` (PK), `CREATORID`, `CREATEDTIME`, `MODIFIEDTIME`. We use CREATEDTIME/MODIFIEDTIME as created_at/updated_at.
- `IsUnique` and `IsMandatory` are per column. No composite unique -> `dedupe_key` column (unique) holds a composed key.
- Foreign Key columns reference parent `ROWID`; on-delete is `null` or `cascade`.
- 100 columns/table (dev). Largest table (`projects`) uses 42.

## Layers
| Layer | Tables |
|---|---|
| Identity & scope | teams, users, employees, team_memberships |
| Operational data | projects, project_assignments, time_entries, attendance_records, leave_records, performance_records, ai_usage_records, product_items, product_item_links |
| Configuration | metric_definitions, application_settings, import_templates, import_mappings |
| Import pipeline | import_jobs, import_rows |
| Reporting | report_snapshots, saved_presentations |
| Governance | audit_logs |

Derived (NOT tables): employee project count, billable/non-billable totals, late-check-in rate, dashboard KPIs. Cached values (`projects.hours_reconciled`) are refreshed server-side.

## Key decisions
1. **Hours truth**: approved `time_entries` are authoritative. `projects.hours_used_reported` / `actual_hours_reported` are source snapshots; reconciliation = `SUM(duration_minutes)/60` over approved entries; differences are surfaced, not overwritten.
2. **Never multiply**: project totals aggregate entries; assignments carry no hours.
3. **One manager, one team**: `users.team_id` is a single FK, so the rule is structural. Admin has NULL team. Server validates `manager => team_id NOT NULL`.
4. **Team scope denormalized**: `team_id` on projects/time_entries/attendance/leave/performance/ai_usage/product_items for cheap scoped queries. Set server-side from the owning project/employee, never from client input.
5. **Missing vs zero vs N/A**: nullable numeric columns (NULL = missing); tri-state varchars (`yes|no|unknown`); `duration_minutes=0` is a real zero. N/A is represented by NULL plus an explicit `*_status`/note where needed.
6. **No raw payloads in Data Store**: source files and row payloads (ndjson) live in File Store; `import_rows` stores status, key, and error codes only.
7. **Soft delete** on business tables (`is_deleted`, `deleted_at`, `deleted_by_user_id`); all reads filter `is_deleted != true`. Audit/import/config tables are not soft-deleted.
8. **Dashboard performance**: filter by team + date range with indexes; aggregate via ZCQL `SUM/COUNT/GROUP BY` and cache into `report_snapshots` (1-year retention, configurable). Paginate with LIMIT/OFFSET.

## Retention (proposed, configurable in `application_settings`)
Report snapshots 365 d; import source files 30 d; import_rows 90 d; audit logs: confirm policy. Expiry never deletes business records.

## `more_details` (added in schema 1.1.0)
- **What**: optional Text column on all 22 tables holding one serialized JSON **object**. Catalyst has no JSON column type; Text max is 10,000 characters (Var Char is 255), so that is the hard cap. Nothing is truncated: oversize is a validation error. Larger payloads belong in File Store.
- **Meaning (same everywhere)**: supplemental attributes with no standard column. NULL = none. It replaces the earlier `source_extra` column on employees/projects.
- **Never used for**: IDs, assignments, work dates/durations, billable class, attendance date/time/late status, leave dates/status, performance periods/metrics, team/manager scope, import job IDs/conflict status, report/presentation ownership. Those stay typed, indexed, validated. Project hours still come from approved `time_entries`, never from assignment count.
- **Security**: scope, role checks, validation and audit logging run on the row, not on `more_details`. Reads return it only to callers allowed to read the row; sensitive tables (leave, performance) apply the same restrictions to it. `audit_logs` records changes to it (redacted per the audit policy).
- **Promotion path**: when an extra key is used often -> (1) add a typed column in the Console, (2) bump `schema_version`, (3) update templates/mappings so the header maps to the new column, (4) one-off backfill function copies `more_details[key]` into the column, validates, then removes the key. Existing rows keep working throughout.
- Reference rules/tests: `db/lib/more_details.js`, `db/tests/`.
