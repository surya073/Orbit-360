'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { buildMoreDetails, resolveMoreDetails, MAX_CHARS } = require('../lib/more_details');

const H = ['Full Name', 'Skills', 'Location', 'Notes'];

test('unmapped columns preserved under original header, mapped ones not duplicated', () => {
  const r = buildMoreDetails(H, ['EXAMPLE A', 'JS', 'Chennai', 'x'], new Set([0]));
  assert.deepStrictEqual(JSON.parse(r.json), { Skills: 'JS', Location: 'Chennai', Notes: 'x' });
});
test('strings, numbers, booleans keep their types', () => {
  const r = buildMoreDetails(['a', 'b', 'c'], ['007', 7, true], new Set());
  assert.deepStrictEqual(JSON.parse(r.json), { a: '007', b: 7, c: true });
});
test('blank cells omitted by default; keepBlanks preserves "" vs null', () => {
  assert.strictEqual(buildMoreDetails(['a', 'b'], ['', null], new Set()).json, null);
  const r = buildMoreDetails(['a', 'b'], ['', null], new Set(), { keepBlanks: true });
  assert.deepStrictEqual(JSON.parse(r.json), { a: '', b: null });
});
test('no extra columns => NULL, not "{}"', () => {
  assert.strictEqual(buildMoreDetails(['a'], ['v'], new Set([0])).json, null);
});
test('duplicate headers stay distinct', () => {
  const r = buildMoreDetails(['Status', 'Status'], ['one', 'two'], new Set());
  assert.deepStrictEqual(JSON.parse(r.json), { Status: 'one', 'Status#1': 'two' });
});
test('key override via mapping', () => {
  const r = buildMoreDetails(['Odd Header!'], ['v'], new Set(), { keyOverrides: { 0: 'odd_header' } });
  assert.deepStrictEqual(JSON.parse(r.json), { odd_header: 'v' });
});
test('special characters and unicode round-trip', () => {
  const v = 'quote " backslash \\ newline \n தமிழ் 😀';
  const r = buildMoreDetails(['k'], [v], new Set());
  assert.strictEqual(JSON.parse(r.json).k, v);
});
test('oversized payload is an error, never truncated', () => {
  const r = buildMoreDetails(['k'], ['x'.repeat(MAX_CHARS)], new Set());
  assert.strictEqual(r.json, null);
  assert.strictEqual(r.errors[0].code, 'MORE_DETAILS_TOO_LARGE');
});
test('exactly at the limit is accepted', () => {
  const pad = MAX_CHARS - JSON.stringify({ k: '' }).length;
  const r = buildMoreDetails(['k'], ['x'.repeat(pad)], new Set());
  assert.strictEqual(r.json.length, MAX_CHARS);
  assert.deepStrictEqual(r.errors, []);
});
test('configured lower limit is honoured but cannot exceed Catalyst cap', () => {
  assert.strictEqual(buildMoreDetails(['k'], ['x'.repeat(200)], new Set(), { maxChars: 100 }).errors[0].code, 'MORE_DETAILS_TOO_LARGE');
  assert.strictEqual(buildMoreDetails(['k'], ['x'.repeat(MAX_CHARS)], new Set(), { maxChars: 999999 }).errors[0].code, 'MORE_DETAILS_TOO_LARGE');
});
test('invalid values and reserved keys are errors', () => {
  assert.strictEqual(buildMoreDetails(['k'], [NaN], new Set()).errors[0].code, 'MORE_DETAILS_INVALID');
  assert.strictEqual(buildMoreDetails(['k'], [{}], new Set()).errors[0].code, 'MORE_DETAILS_INVALID');
  assert.strictEqual(buildMoreDetails(['__proto__'], ['x'], new Set()).errors[0].code, 'MORE_DETAILS_INVALID');
});
test('dates serialize to ISO', () => {
  const r = buildMoreDetails(['d'], [new Date('2025-01-02T00:00:00Z')], new Set());
  assert.strictEqual(JSON.parse(r.json).d, '2025-01-02T00:00:00.000Z');
});
test('retry is idempotent: same row => identical value regardless of column order', () => {
  const a = buildMoreDetails(['x', 'y'], ['1', '2'], new Set()).json;
  const b = buildMoreDetails(['y', 'x'], ['2', '1'], new Set()).json;
  assert.strictEqual(a, b);
});
test('retrying an import by dedupe_key creates no duplicate and no change', () => {
  const store = new Map();
  const run = () => {
    const j = buildMoreDetails(['id', 'extra'], ['EXAMPLE-1', 'v'], new Set([0])).json;
    const key = 'EXAMPLE-1';
    if (!store.has(key)) store.set(key, { more_details: j }); else store.get(key).more_details = j;
  };
  run(); run();
  assert.strictEqual(store.size, 1);
  assert.deepStrictEqual(JSON.parse(store.get('EXAMPLE-1').more_details), { extra: 'v' });
});
test('conflict resolution: update merges, keep_existing/skip leave unchanged', () => {
  const ex = JSON.stringify({ a: '1', b: '2' }), inc = JSON.stringify({ b: '3', c: '4' });
  assert.deepStrictEqual(JSON.parse(resolveMoreDetails(ex, inc, 'update').json), { a: '1', b: '3', c: '4' });
  assert.strictEqual(resolveMoreDetails(ex, inc, 'keep_existing').json, ex);
  assert.strictEqual(resolveMoreDetails(ex, inc, 'skip').json, ex);
  assert.strictEqual(resolveMoreDetails(null, inc, 'update').json, JSON.stringify({ b: '3', c: '4' }));
});
test('merge that overflows, or corrupt existing value, is an error', () => {
  const ex = JSON.stringify({ a: 'x'.repeat(9000) }), inc = JSON.stringify({ b: 'y'.repeat(2000) });
  assert.strictEqual(resolveMoreDetails(ex, inc, 'update').errors[0].code, 'MORE_DETAILS_TOO_LARGE');
  assert.strictEqual(resolveMoreDetails('not json', inc, 'update').errors[0].code, 'MORE_DETAILS_INVALID');
  assert.strictEqual(resolveMoreDetails('[1]', inc, 'update').errors[0].code, 'MORE_DETAILS_INVALID');
});
