# Catalyst Console Checklist (generated - do not hand-edit)

Project `46135000000311001` (Development). **Status: NOT created remotely.** Tick items only after verifying in the Console.

Console type names: confirm the exact dropdown labels (Int / Big Int / Double / Boolean / Date / DateTime) when creating the first column of each type.

Do NOT add ROWID, CREATORID, CREATEDTIME, MODIFIEDTIME - Catalyst creates them.

## Phase 1 - create all 22 tables and their non-FK columns

Create tables in this order (phase 1 has no FK columns, so any order works; after phase 1 every FK parent exists, so phase 2 order is free):

`metric_definitions`, `application_settings`, `import_templates`, `import_mappings`, `product_item_links`, `teams`, `import_jobs`, `audit_logs`, `employees`, `team_memberships`, `users`, `attendance_records`, `import_rows`, `leave_records`, `performance_records`, `projects`, `ai_usage_records`, `product_items`, `project_assignments`, `report_snapshots`, `saved_presentations`, `time_entries`

### [ ] `metric_definitions`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `metric_code` | Var Char (max 80) | Yes | Yes | 1 |
| [ ] | `name` | Var Char (max 150) | Yes |  | 1 |
| [ ] | `module` | Var Char (max 40) | Yes |  | 1 |
| [ ] | `value_type` | Var Char (max 20) |  |  | 1 |
| [ ] | `scale_min` | Double |  |  | 1 |
| [ ] | `scale_max` | Double |  |  | 1 |
| [ ] | `weight` | Double |  |  | 1 |
| [ ] | `aggregation` | Var Char (max 20) |  |  | 1 |
| [ ] | `description` | Text (max 10,000) |  |  | 1 |
| [ ] | `is_active` | Boolean |  |  | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

### [ ] `application_settings`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `setting_key` | Var Char (max 100) | Yes |  | 1 |
| [ ] | `scope` | Var Char (max 10) |  |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `setting_value` | Text (max 10,000) |  |  | 1 |
| [ ] | `value_type` | Var Char (max 20) |  |  | 1 |
| [ ] | `description` | Text (max 10,000) |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

### [ ] `import_templates`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `module` | Var Char (max 40) | Yes |  | 1 |
| [ ] | `name` | Var Char (max 150) | Yes |  | 1 |
| [ ] | `version` | Var Char (max 20) |  |  | 1 |
| [ ] | `file_type` | Var Char (max 10) |  |  | 1 |
| [ ] | `header_row` | Int |  |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_system` | Boolean |  |  | 1 |
| [ ] | `is_active` | Boolean |  |  | 1 |
| [ ] | `unmapped_policy` | Var Char (max 20) |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

### [ ] `import_mappings`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `template_id` | Foreign Key -> `import_templates`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `source_column` | Var Char (max 200) | Yes |  | 1 |
| [ ] | `source_index` | Int |  |  | 1 |
| [ ] | `target_field` | Var Char (max 100) |  |  | 1 |
| [ ] | `more_details_key` | Var Char (max 200) |  |  | 1 |
| [ ] | `exclude_ack_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `transform` | Var Char (max 40) |  |  | 1 |
| [ ] | `transform_options` | Text (max 10,000) |  |  | 1 |
| [ ] | `is_required` | Boolean |  |  | 1 |
| [ ] | `sort_order` | Int |  |  | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `template_id, sort_order`

### [ ] `product_item_links`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `item_id` | Foreign Key -> `product_items`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `linked_item_id` | Foreign Key -> `product_items`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `link_type` | Var Char (max 30) | Yes |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

### [ ] `teams`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `team_code` | Var Char (max 60) | Yes | Yes | 1 |
| [ ] | `name` | Var Char (max 150) | Yes |  | 1 |
| [ ] | `description` | Text (max 10,000) |  |  | 1 |
| [ ] | `is_active` | Boolean |  |  | 1 |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

### [ ] `import_jobs`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `module` | Var Char (max 40) | Yes |  | 1 |
| [ ] | `template_id` | Foreign Key -> `import_templates`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `file_name` | Var Char (max 255) | Yes |  | 1 |
| [ ] | `file_type` | Var Char (max 10) |  |  | 1 |
| [ ] | `file_store_file_id` | Big Int |  |  | 1 |
| [ ] | `file_sha256` | Var Char (max 64) |  |  | 1 |
| [ ] | `uploaded_by_user_id` | Foreign Key -> `users`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `status` | Var Char (max 30) | Yes |  | 1 |
| [ ] | `default_conflict_policy` | Var Char (max 20) |  |  | 1 |
| [ ] | `total_rows` | Int |  |  | 1 |
| [ ] | `valid_rows` | Int |  |  | 1 |
| [ ] | `invalid_rows` | Int |  |  | 1 |
| [ ] | `conflict_rows` | Int |  |  | 1 |
| [ ] | `unmapped_column_count` | Int |  |  | 1 |
| [ ] | `more_details_error_rows` | Int |  |  | 1 |
| [ ] | `created_rows` | Int |  |  | 1 |
| [ ] | `updated_rows` | Int |  |  | 1 |
| [ ] | `skipped_rows` | Int |  |  | 1 |
| [ ] | `failed_rows` | Int |  |  | 1 |
| [ ] | `started_at` | DateTime |  |  | 1 |
| [ ] | `finished_at` | DateTime |  |  | 1 |
| [ ] | `error_summary` | Text (max 10,000) |  |  | 1 |
| [ ] | `mapping_snapshot` | Text (max 10,000) |  |  | 1 |
| [ ] | `file_expires_at` | DateTime |  |  | 1 |
| [ ] | `commit_cursor` | Int |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  |  | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `team_id, module, status`; `file_sha256`

### [ ] `audit_logs`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `actor_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `action` | Var Char (max 40) | Yes |  | 1 |
| [ ] | `entity_table` | Var Char (max 60) | Yes |  | 1 |
| [ ] | `entity_row_id` | Big Int |  |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `before_json` | Text (max 10,000) |  |  | 1 |
| [ ] | `after_json` | Text (max 10,000) |  |  | 1 |
| [ ] | `reason` | Text (max 10,000) |  |  | 1 |
| [ ] | `request_id` | Var Char (max 60) |  |  | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `entity_table, entity_row_id`; `actor_user_id`

### [ ] `employees`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `employee_code` | Var Char (max 60) |  | Yes | 1 |
| [ ] | `source_sno` | Int |  |  | 1 |
| [ ] | `full_name` | Var Char (max 200) | Yes |  | 1 |
| [ ] | `email_normalized` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `job_role` | Var Char (max 120) |  |  | 1 |
| [ ] | `joining_date` | Date |  |  | 1 |
| [ ] | `reports_to_employee_id` | Foreign Key -> `employees`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `reports_to_raw` | Var Char (max 200) |  |  | 1 |
| [ ] | `employment_status` | Var Char (max 30) |  |  | 1 |
| [ ] | `primary_team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `primary_team_id, employment_status`; `source_system, source_record_id`

### [ ] `team_memberships`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `team_id` | Foreign Key -> `teams`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `membership_role` | Var Char (max 30) |  |  | 1 |
| [ ] | `start_date` | Date |  |  | 1 |
| [ ] | `end_date` | Date |  |  | 1 |
| [ ] | `is_active` | Boolean |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `team_id, employee_id`

### [ ] `users`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `catalyst_user_id` | Var Char (max 40) | Yes | Yes | 1 |
| [ ] | `email` | Var Char (max 255) | Yes | Yes | 1 |
| [ ] | `display_name` | Var Char (max 150) |  |  | 1 |
| [ ] | `app_role` | Var Char (max 20) | Yes |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_active` | Boolean |  |  | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `app_role, team_id`

### [ ] `attendance_records`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `attendance_date` | Date | Yes |  | 1 |
| [ ] | `reporting_month` | Var Char (max 7) |  |  | 1 |
| [ ] | `check_in_time_local` | Var Char (max 8) |  |  | 1 |
| [ ] | `late_status` | Var Char (max 10) | Yes |  | 1 |
| [ ] | `late_reason` | Text (max 10,000) |  |  | 1 |
| [ ] | `late_checkin_raw` | Var Char (max 120) |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `team_id, attendance_date`; `employee_id, attendance_date`

### [ ] `import_rows`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `row_number` | Int | Yes |  | 1 |
| [ ] | `status` | Var Char (max 20) | Yes |  | 1 |
| [ ] | `business_key` | Var Char (max 255) |  |  | 1 |
| [ ] | `conflict_target_row_id` | Big Int |  |  | 1 |
| [ ] | `resolution` | Var Char (max 20) |  |  | 1 |
| [ ] | `resolved_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `resolved_at` | DateTime |  |  | 1 |
| [ ] | `error_codes` | Var Char (max 255) |  |  | 1 |
| [ ] | `error_detail` | Text (max 10,000) |  |  | 1 |
| [ ] | `row_hash` | Var Char (max 64) |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `import_job_id, status`

### [ ] `leave_records`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `leave_type` | Var Char (max 60) | Yes |  | 1 |
| [ ] | `start_date` | Date | Yes |  | 1 |
| [ ] | `end_date` | Date | Yes |  | 1 |
| [ ] | `units` | Double |  |  | 1 |
| [ ] | `unit_type` | Var Char (max 10) |  |  | 1 |
| [ ] | `status` | Var Char (max 20) | Yes |  | 1 |
| [ ] | `reason` | Text (max 10,000) |  |  | 1 |
| [ ] | `approver_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `decided_at` | DateTime |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `employee_id, start_date`; `team_id, status`

### [ ] `performance_records`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `review_cycle` | Var Char (max 60) | Yes |  | 1 |
| [ ] | `period_start` | Date | Yes |  | 1 |
| [ ] | `period_end` | Date | Yes |  | 1 |
| [ ] | `metric_definition_id` | Foreign Key -> `metric_definitions`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `metric_value` | Double |  |  | 1 |
| [ ] | `metric_text` | Var Char (max 255) |  |  | 1 |
| [ ] | `metric_scale` | Var Char (max 40) |  |  | 1 |
| [ ] | `reviewer_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `reviewer_employee_id` | Foreign Key -> `employees`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `review_status` | Var Char (max 20) | Yes |  | 1 |
| [ ] | `comments` | Text (max 10,000) |  |  | 1 |
| [ ] | `evidence_ref` | Text (max 10,000) |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `employee_id, review_cycle`; `team_id, period_start`

### [ ] `projects`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `project_code` | Var Char (max 60) |  | Yes | 1 |
| [ ] | `source_sno` | Int |  |  | 1 |
| [ ] | `project_name` | Var Char (max 255) | Yes |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `project_type` | Var Char (max 80) |  |  | 1 |
| [ ] | `plan_type` | Var Char (max 80) |  |  | 1 |
| [ ] | `region` | Var Char (max 80) |  |  | 1 |
| [ ] | `current_status` | Var Char (max 60) |  |  | 1 |
| [ ] | `contract_status` | Var Char (max 60) |  |  | 1 |
| [ ] | `completion_status` | Var Char (max 60) |  |  | 1 |
| [ ] | `meeting_schedule` | Var Char (max 150) |  |  | 1 |
| [ ] | `second_host_raw` | Var Char (max 200) |  |  | 1 |
| [ ] | `second_host_employee_id` | Foreign Key -> `employees`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `first_start_date` | Date |  |  | 1 |
| [ ] | `current_start_date` | Date |  |  | 1 |
| [ ] | `end_date` | Date |  |  | 1 |
| [ ] | `internal_due_date` | Date |  |  | 1 |
| [ ] | `client_due_date` | Date |  |  | 1 |
| [ ] | `completed_date` | Date |  |  | 1 |
| [ ] | `total_renewals` | Int |  |  | 1 |
| [ ] | `hours_purchased_past` | Double |  |  | 1 |
| [ ] | `hours_purchased_current` | Double |  |  | 1 |
| [ ] | `hours_used_reported` | Double |  |  | 1 |
| [ ] | `estimated_hours` | Double |  |  | 1 |
| [ ] | `actual_hours_reported` | Double |  |  | 1 |
| [ ] | `hours_reconciled` | Double |  |  | 1 |
| [ ] | `hours_reconciled_at` | DateTime |  |  | 1 |
| [ ] | `comments` | Text (max 10,000) |  |  | 1 |
| [ ] | `delay_reason` | Text (max 10,000) |  |  | 1 |
| [ ] | `consumption_report_url` | Text (max 10,000) |  |  | 1 |
| [ ] | `bandwidth` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `team_id, current_status`; `source_system, source_record_id`

### [ ] `ai_usage_records`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `project_id` | Foreign Key -> `projects`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `tool_name` | Var Char (max 100) | Yes |  | 1 |
| [ ] | `tool_category` | Var Char (max 30) | Yes |  | 1 |
| [ ] | `access_type` | Var Char (max 60) |  |  | 1 |
| [ ] | `is_shared_access` | Var Char (max 10) |  |  | 1 |
| [ ] | `shared_access_raw` | Text (max 10,000) |  |  | 1 |
| [ ] | `usage_percent_reported` | Double |  |  | 1 |
| [ ] | `usage_purpose` | Text (max 10,000) |  |  | 1 |
| [ ] | `projects_raw` | Text (max 10,000) |  |  | 1 |
| [ ] | `reporting_period` | Var Char (max 20) |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `employee_id, tool_category`; `team_id, reporting_period`

### [ ] `product_items`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `item_type` | Var Char (max 20) | Yes |  | 1 |
| [ ] | `title` | Var Char (max 255) | Yes |  | 1 |
| [ ] | `description` | Text (max 10,000) |  |  | 1 |
| [ ] | `project_id` | Foreign Key -> `projects`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `status` | Var Char (max 40) |  |  | 1 |
| [ ] | `priority` | Var Char (max 20) |  |  | 1 |
| [ ] | `assignee_employee_id` | Foreign Key -> `employees`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `reporter_employee_id` | Foreign Key -> `employees`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `parent_item_id` | Foreign Key -> `product_items`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `release_item_id` | Foreign Key -> `product_items`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `created_on` | Date |  |  | 1 |
| [ ] | `start_date` | Date |  |  | 1 |
| [ ] | `due_date` | Date |  |  | 1 |
| [ ] | `completed_date` | Date |  |  | 1 |
| [ ] | `estimated_hours` | Double |  |  | 1 |
| [ ] | `actual_hours` | Double |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `project_id, item_type, status`; `assignee_employee_id`

### [ ] `project_assignments`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `project_id` | Foreign Key -> `projects`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete cascade | Yes |  | 2 (after parent exists) |
| [ ] | `role_in_project` | Var Char (max 120) |  |  | 1 |
| [ ] | `is_second_host` | Boolean |  |  | 1 |
| [ ] | `allocation_percent` | Double |  |  | 1 |
| [ ] | `contribution_percent_reported` | Double |  |  | 1 |
| [ ] | `is_working` | Boolean |  |  | 1 |
| [ ] | `start_date` | Date |  |  | 1 |
| [ ] | `end_date` | Date |  |  | 1 |
| [ ] | `is_active` | Boolean |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `employee_id`; `project_id`

### [ ] `report_snapshots`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `report_type` | Var Char (max 60) | Yes |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `period_start` | Date |  |  | 1 |
| [ ] | `period_end` | Date |  |  | 1 |
| [ ] | `reporting_period` | Var Char (max 20) |  |  | 1 |
| [ ] | `parameters` | Text (max 10,000) |  |  | 1 |
| [ ] | `summary_json` | Text (max 10,000) |  |  | 1 |
| [ ] | `data_file_id` | Big Int |  |  | 1 |
| [ ] | `data_version` | Var Char (max 20) |  |  | 1 |
| [ ] | `status` | Var Char (max 20) |  |  | 1 |
| [ ] | `generated_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `generated_at` | DateTime |  |  | 1 |
| [ ] | `expires_at` | DateTime |  |  | 1 |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `report_type, reporting_period, team_id`; `expires_at`

### [ ] `saved_presentations`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `title` | Var Char (max 200) | Yes |  | 1 |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `created_by_user_id` | Foreign Key -> `users`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `slides_config` | Text (max 10,000) |  |  | 1 |
| [ ] | `status` | Var Char (max 20) |  |  | 1 |
| [ ] | `last_presented_at` | DateTime |  |  | 1 |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `team_id`

### [ ] `time_entries`

| ok | Column | Type | Mandatory | Unique | Phase |
|---|---|---|---|---|---|
| [ ] | `employee_id` | Foreign Key -> `employees`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `project_id` | Foreign Key -> `projects`, on delete null | Yes |  | 2 (after parent exists) |
| [ ] | `team_id` | Foreign Key -> `teams`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `work_date` | Date | Yes |  | 1 |
| [ ] | `start_at` | DateTime |  |  | 1 |
| [ ] | `end_at` | DateTime |  |  | 1 |
| [ ] | `duration_minutes` | Int | Yes |  | 1 |
| [ ] | `is_billable` | Boolean | Yes |  | 1 |
| [ ] | `work_category` | Var Char (max 60) |  |  | 1 |
| [ ] | `work_description` | Text (max 10,000) |  |  | 1 |
| [ ] | `approval_status` | Var Char (max 20) | Yes |  | 1 |
| [ ] | `approved_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `approved_at` | DateTime |  |  | 1 |
| [ ] | `dedupe_key` | Var Char (max 255) |  | Yes | 1 |
| [ ] | `source_system` | Var Char (max 60) |  |  | 1 |
| [ ] | `source_record_id` | Var Char (max 120) |  |  | 1 |
| [ ] | `import_job_id` | Foreign Key -> `import_jobs`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `is_deleted` | Boolean |  |  | 1 |
| [ ] | `deleted_at` | DateTime |  |  | 1 |
| [ ] | `deleted_by_user_id` | Foreign Key -> `users`, on delete null |  |  | 2 (after parent exists) |
| [ ] | `more_details` | Text (max 10,000) |  |  | 1 |

Indexes (only if Console supports): `project_id, work_date`; `employee_id, work_date`; `team_id, work_date, approval_status`

## Phase 2 - Foreign Key columns
Add every row marked phase 2 above, in any order. Self-references (`employees.reports_to_employee_id`, `product_items.parent_item_id/release_item_id`) are added after their own table exists.

## Phase 3 - seed
Load `db/seed/application_settings.json` (config only, no company data).

## Phase 4 - verify
Compare the Console Schema View of each table with this list; record column count (expected = columns listed + 4 system).