# Roles and Permissions

Roles: `admin`, `manager` (`users.app_role`). Enforced in Catalyst Functions; the browser never supplies `team_id` for scoping.

## Rules
- Resolve the caller from Catalyst Authentication -> `users` row on every request; reject inactive/unknown users.
- **Admin**: all teams, all modules, user/team/settings/template management.
- **Manager**: `users.team_id` must be set. Every query adds `team_id = <caller team>`; every write sets `team_id` server-side. Referenced IDs (employee, project) are checked to belong to the caller's team before use.
- **One team per manager**: single FK `users.team_id`. Multiple managers may share a team. Changing a manager's team is admin-only and audited.
- **Presentations**: managers read/write any `saved_presentations` with their `team_id` (including other managers'); admins read all. Snapshots referenced by a deck are re-checked for team scope on open.
- **Imports**: managers import only into their team; rows resolving to another team's records are rejected as `OUT_OF_SCOPE`. Template `team_id` NULL (global) is usable by all; team templates only by that team.
- **Sensitive**: `leave_records.reason`, `performance_records.comments` returned only to admin and the owning team's managers; omit from list endpoints/exports by default.
- **Audit**: all create/update/delete, conflict resolutions, role/team changes -> `audit_logs` (server-written; no client write path).

## Matrix
| Resource | Admin | Manager (own team) |
|---|---|---|
| teams, users, settings, metric_definitions | CRUD | read teams/own metrics |
| employees, projects, assignments, time, attendance, leave, performance, ai_usage, product_items | CRUD all | CRUD team scope |
| import_jobs / rows | all | own team |
| report_snapshots | all | own team |
| saved_presentations | all | own team (any manager's) |
| audit_logs | read all | read own-team entries (optional) |

## Gaps to close in code
Data Store cannot enforce row-level scope; a shared `requireScope()` helper must wrap every function. Add tests that a manager token cannot read/write another team's rows via any endpoint.

## `more_details`
It is part of the row: same team scope, role checks and audit as the row itself. Scoping, role and ownership decisions never read it. Writes outside a manager's team are rejected before any `more_details` is evaluated. On leave and performance tables it is returned only to callers who may see those sensitive fields.
